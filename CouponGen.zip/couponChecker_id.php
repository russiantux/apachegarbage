<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    

    <title>Coupon Checker</title>

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link href="https://getbootstrap.com/docs/4.0/examples/sign-in/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
 
    <form class="form-signin" method="post" action="processidmarking.php">
      <img class="mb-4" src="alphalogo.png" alt="" width="72" height="72">
      <h1 class="h3 mb-3 font-weight-normal">Coupon Checker</h1>
      <?php
       
        $dbhost = "138.68.8.58";
        $dbuser = "CCcouponGen";
        $dbName = "coupngenCC";
        $dbpass = "123456";
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass, $dbName);
        $idvalid = false;
        
        
        $id = (isset($_POST['inputID']) ? $_POST['inputID'] : null);
        
        if (!$conn){
            echo "Can't Connect to the database, notify the admin ASAP";
        }
        else{
            $result = mysqli_query($conn,"SELECT couponID FROM couponID WHERE couponID = '" . $id . "'");  
            if ($result->num_rows !== 0) {
                
                echo '<h1 class="h3 mb-3 font-weight-normal"><u>Coupon is valid.</u></h1>';
                $idvalid = true;
                //
                echo '<br>';
            }
         else {           
                  echo '<h1 class="h3 mb-3 font-weight-normal">Coupon is not valid.</h1>';
            }
        }

        mysqli_close($conn);
   
  
       
      echo '<div class="checkbox mb-3">';
      
    echo '<br>';
    echo  '</div>';
    if ($idvalid == false){
    echo '<h1 class="h3 mb-3 font-weight-normal"><a href="couponChecker.php">Scan another coupon</a></h1>';
}
else{
    echo '<button class="btn btn-lg btn-success btn-block" type="submit" name="markBtn">Mark as used</button>';
    echo '<br>';
        echo '<h1 class="h3 mb-3 font-weight-normal"><a href="couponChecker.php">Scan another coupon</a></h1>';
}
?>
    <input type="text" name="inputID" class="form-control" value= "<?php echo $id ?>" >
   <p class="mt-5 mb-3 text-muted">&copy; 2018 Campus Computers</p>
    </form>
     
  </body>
</html>
