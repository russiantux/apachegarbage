<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    

    <title>Coupon Checker</title>

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link href="https://getbootstrap.com/docs/4.0/examples/sign-in/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
  <?php 
        $dbhost = "138.68.8.58";
        $dbuser = "CCcouponGen";
        $dbName = "coupngenCC";
        $dbpass = "123456";
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass, $dbName);
        $verifiedid = 0;
        if(!$conn){
            echo "Can't Connect to the database, notify the admin ASAP";
        }
        else{
        
           // $generatedid = rand(0, 15000);
           // $result = mysqli_query($conn,"SELECT couponID FROM couponID WHERE couponID = '.$generatedid.'");  
       //if($result->num_rows == 0) {
           // $verifiedid = $generatedid;
            
           // $result_2 = mysqli_query($conn, "INSERT INTO couponID(couponID, isUsed) VALUES ($verifiedid, '0') ");
        //} else {
            
       // }
        
    }
        mysqli_close($conn);
    ?>
    <form class="form-signin" method="post" action="couponChecker_id.php">
      <img class="mb-4" src="alphalogo.png" alt="" width="72" height="72">
      <h1 class="h3 mb-3 font-weight-normal">Coupon Checker</h1>
      
      <input type="text" name="inputID" class="form-control" placeholder="Coupon ID " >
      
      <div class="checkbox mb-3">
        <br>
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit" name="checkBtn">Check ID</button>
      <p class="mt-5 mb-3 text-muted">&copy; 2018 Campus Computers</p>
    </form>
    
  </body>
</html>
