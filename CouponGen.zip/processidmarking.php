<?php
 
        $dbhost = "138.68.8.58";
        $dbuser = "CCcouponGen";
        $dbName = "coupngenCC";
        $dbpass = "123456";
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass, $dbName);
        
        
        $id = (isset($_POST['inputID']) ? $_POST['inputID'] : null);
        
        if (!$conn){
            echo "Can't Connect to the database, notify the admin ASAP";
        }
        else{
            
                    $result_2 = mysqli_query($conn, "UPDATE couponID SET isUsed='1' WHERE couponID='" . $id ."'");
                    echo "UPDATE couponid SET isUsed='1' WHERE couponid='" .$id . "'";
                    header("Location: http://node25.codenvy.io:42269//CouponGen/couponChecker.php"); /* Redirect browser */
        
        }

        mysqli_close($conn);
    ?>

