<!DOCTYPE html>
<html>
    <head>
        
       

    <title>5% Off Coupon | Campus Computers</title>


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link href="https://getbootstrap.com/docs/4.0/examples/cover/cover.css" rel="stylesheet">
    </head>
    <body>
    <?php 
        $dbhost = "138.68.8.58";
        $dbuser = "CCcouponGen";
        $dbName = "coupngenCC";
        $dbpass = "123456";
        
        $conn = mysqli_connect($dbhost,$dbuser,$dbpass, $dbName);
        
        if(!$conn){
            echo "Can't Connect to the database, notify the admin ASAP";
        }
        else{
        
    }

        mysqli_close($conn);
    ?>
        
        
        <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
      <header class="masthead mb-auto">
        <div class="inner">
          <h3 class="masthead-brand">Campus Computers</h3>
          <nav class="nav nav-masthead justify-content-center">
            <a class="nav-link" href="https://campuscomputersca.com">Main Website</a>           
          </nav>
        </div>
      </header>

      <main role="main" class="inner cover">
        <h1 class="cover-heading">5% off your first order</h1>
        <p class="lead">Generate a coupon and use it to get 5% off your first order at Campus Computers, whether you need a networking solution for your business or you need to repair your phone or computer. </p>
        <p class="lead">
         <form method="post" action="generatedcoupon.php">
        <button class="btn btn-lg btn-secondary" type="submit" name="submit">Generate Coupon</button>
        </form>
        </p>
      </main>

      <footer class="mastfoot mt-auto">
        <div class="inner">
          <p>&copy; 2018 <a href="https://campuscomputersca.com">  Campus Computers</a>. Coupon system developed by <a href="http://reduxsoftware.net">REDUXsoftware</a></p>
        </div>
      </footer>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
</html>